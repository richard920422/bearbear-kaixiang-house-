const menu = document.querySelector('.menu');
const nav = document.querySelector('.nav nav');
menu?.addEventListener('click', () => {
  nav.classList.toggle('open');
});
document.querySelectorAll('.nav nav a').forEach(a => {
  a.addEventListener('click', () => nav.classList.remove('open'));
});
const style = document.createElement('style');
style.textContent = `
@media(max-width:900px){
  .nav nav.open{display:flex;position:absolute;top:68px;left:0;right:0;background:#070707;border-bottom:1px solid #222;padding:22px 7vw;flex-direction:column;gap:22px}
}`;
document.head.appendChild(style);
